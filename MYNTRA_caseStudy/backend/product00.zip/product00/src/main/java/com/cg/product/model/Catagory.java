package com.cg.product.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Catagory {

	private Integer id;
	private String name;
	private String brand;

	
}
