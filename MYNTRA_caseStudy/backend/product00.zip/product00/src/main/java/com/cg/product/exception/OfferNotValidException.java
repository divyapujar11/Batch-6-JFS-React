package com.cg.product.exception;

public class OfferNotValidException extends RuntimeException {
	public OfferNotValidException(String s) {
		super (s);
	}

}
